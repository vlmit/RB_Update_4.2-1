import { ExtensionContainer, ExtensionStage } from 'tessa/extensions';

import { ODControlTaskCustomButtonUIExtension } from './ui/ODControlTaskCustomButtonUIExtension';
//mobile
import { ODCloseCardUIExtension } from './mobile_ui/ODCloseCardUIExtension';


ExtensionContainer.instance.registerExtension({
  extension: ODControlTaskCustomButtonUIExtension,
  stage: ExtensionStage.AfterPlatform
});
ExtensionContainer.instance.registerExtension({
  extension: ODCloseCardUIExtension,
  stage: ExtensionStage.AfterPlatform
});
